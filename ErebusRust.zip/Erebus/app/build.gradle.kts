// Заглушка: настоящая сборка выполняется в settings.gradle.kts (см. комментарий там).
tasks.register("assembleDebug")
