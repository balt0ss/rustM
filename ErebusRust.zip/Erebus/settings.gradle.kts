// Erebus Rust: оболочка для сборки Rust-клиента Minecraft (проект Pomme) под Android.
// Workflow вызывает :app:assembleDebug и ждёт APK в app/build/outputs/apk/debug/. Этот файл
// скачивает исходники Pomme (с закреплённого коммита), ставит Rust, NDK и cargo-ndk, собирает
// нативную библиотеку клиента, переименовывает приложение и собирает APK через его gradlew.
rootProject.name = "ErebusRustBuild"
include(":app")

val root = settings.settingsDir
val src = File(root, "pomme")
val POMME_URL = "https://github.com/PommeMC/Client"
val POMME_SHA = "cda2f5ed020a5ba87d673d3c7840003496615bec"
val NDK_VERSION = "27.2.12479018"

val tail = ArrayDeque<String>()

fun sh(dir: File, env: Map<String, String>, script: String): Int {
    val pb = ProcessBuilder("bash", "-c", script).directory(dir).redirectErrorStream(true)
    pb.environment().putAll(env)
    val p = pb.start()
    p.inputStream.bufferedReader().forEachLine { line ->
        println(line)
        tail.addLast(line)
        if (tail.size > 150) tail.removeFirst()
    }
    return p.waitFor()
}

fun step(title: String, dir: File, env: Map<String, String>, script: String, optional: Boolean = false) {
    println(">>> Erebus Rust: $title")
    val code = sh(dir, env, script)
    if (code != 0 && !optional) {
        throw GradleException("Шаг «$title» завершился с ошибкой (код $code). Последние строки:\n" + tail.joinToString("\n"))
    }
}

if (System.getenv("EREBUS_INNER") != "1") {
    val sdk = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
        ?: throw GradleException("ANDROID_HOME не задан")
    val ndk = "$sdk/ndk/$NDK_VERSION"
    val env = mapOf(
        "EREBUS_INNER" to "1",
        "ANDROID_HOME" to sdk,
        "ANDROID_SDK_ROOT" to sdk,
        "ANDROID_NDK_HOME" to ndk,
        "ANDROID_NDK_ROOT" to ndk,
        "GIT_LFS_SKIP_SMUDGE" to "1",
        "CARGO_TERM_COLOR" to "never",
    )

    // 1. Исходники Pomme на нужном коммите вместе с SteelMC
    if (!File(src, ".git").exists()) {
        src.deleteRecursively(); src.mkdirs()
        step("скачиваю Pomme", src, env, """
            git init -q && git remote add origin $POMME_URL &&
            git fetch -q --depth 1 origin $POMME_SHA && git checkout -q FETCH_HEAD &&
            git submodule update --init --depth 1 --recursive
        """.trimIndent())
        // Свои правки клиента (сенсорное управление в стиле лаунчера)
        step("применяю правки клиента", src, env,
            "for p in '${root.absolutePath}'/patches/*.patch; do echo \"patch: ${'$'}p\"; git apply --whitespace=nowarn \"${'$'}p\"; done")
    }

    // 2. Системные пакеты, нужные сборке shaderc и Vulkan (на runner'е GitHub есть sudo)
    step("системные пакеты", root, env,
        "(sudo apt-get update -qq && sudo apt-get install -y -qq cmake ninja-build python3 libvulkan-dev pkg-config) || true",
        optional = true)

    // 3. Android SDK: NDK, CMake, платформа и build-tools
    val sm = listOf("$sdk/cmdline-tools/latest/bin/sdkmanager", "$sdk/tools/bin/sdkmanager").firstOrNull { File(it).exists() }
    if (sm != null) {
        step("Android SDK и NDK $NDK_VERSION", root, env,
            "yes | '$sm' --licenses >/dev/null || true; '$sm' 'ndk;$NDK_VERSION' 'cmake;3.22.1' 'platforms;android-35' 'build-tools;35.0.0'")
    }

    // 4. Rust: закреплённая версия nightly, цель Android и cargo-ndk
    step("Rust (nightly из rust-toolchain.toml) и цель aarch64-linux-android", src, env, """
        CH=${'$'}(grep -E '^channel' rust-toolchain.toml | sed -E 's/.*"([^"]+)".*/\1/')
        echo "toolchain: ${'$'}CH"
        rustup toolchain install "${'$'}CH" --profile minimal -c rust-src
        rustup target add aarch64-linux-android --toolchain "${'$'}CH"
        cargo install cargo-ndk@4.1.2 --locked
    """.trimIndent())

    // 5. OpenAL Soft для Android (собирается из исходников)
    step("OpenAL Soft", src, env,
        "python3 tools/build_openal.py android pomme-android/app/src/main/jniLibs/arm64-v8a")

    // 6. Клиент в release: debug-сборка Rust в игре слишком медленная
    step("сборка Rust-клиента (долго, 20–40 минут)", src, env,
        "cargo ndk -t arm64-v8a -o pomme-android/app/src/main/jniLibs build --release -p pomme-android")

    // 7. Своё имя, идентификатор и иконка
    println(">>> Erebus Rust: переименовываю приложение")
    val android = File(src, "pomme-android/app")
    val gradle = File(android, "build.gradle.kts")
    gradle.writeText(gradle.readText().replace("applicationId = \"com.pommemc.client\"", "applicationId = \"app.erebus.rust\""))
    val manifestFile = File(android, "src/main/AndroidManifest.xml")
    manifestFile.writeText(
        manifestFile.readText()
            .replace("android:label=\"Pomme\"", "android:label=\"Erebus Rust\" android:icon=\"@mipmap/ic_launcher\"")
    )
    File(root, "overlay/res").copyRecursively(File(android, "src/main/res"), overwrite = true)

    // 8. APK через его собственный gradlew (Gradle 8.10, AGP 8.7, нужен JDK 17)
    step("сборка APK", File(src, "pomme-android"), env, "bash gradlew assembleDebug --stacktrace --no-daemon")

    val apks = File(src, "pomme-android/app/build/outputs/apk/debug").listFiles { f -> f.extension == "apk" }
    if (apks == null || apks.isEmpty()) throw GradleException("APK не найден после сборки")
    val out = File(root, "app/build/outputs/apk/debug")
    out.mkdirs()
    apks[0].copyTo(File(out, "ErebusRust.apk"), overwrite = true)
    println(">>> Erebus Rust: готово, ${apks[0].name} -> ${out}/ErebusRust.apk")
}
