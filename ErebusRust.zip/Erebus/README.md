# Erebus Rust

Отдельный проект: Rust-клиент Minecraft Java Edition ([Pomme](https://github.com/PommeMC/Client), GPL-3.0)
в виде Android-приложения `app.erebus.rust`. Исходники Pomme не хранятся здесь: сборка скачивает их с закреплённого
коммита (см. `POMME_SHA` в `settings.gradle.kts`), собирает нативный клиент и APK.

Нужна лицензионная игра и вход через Microsoft. Одиночная игра на Android в Pomme пока отключена,
играть можно на серверах. Первый запуск докачивает ресурсы игры (около 500 МБ). Требуется Vulkan 1.1 (Android 10+).

## Сенсорное управление

Правка `patches/touch-controls.patch` заменяет стандартное управление Pomme на раскладку в стиле Java-лаунчера:
D-pad из стрелок слева, Jump и Sneak справа, Hit и Place в верхних углах, прокрутка хотбара, а сверху ряд кнопок
F1, F3, F5, Pick, Tab, Chat, `/`, Inv, Drop и пауза. Остальной экран это обзор. Патч применяется при сборке.
