# Erebus Rust

Отдельный проект: Rust-клиент Minecraft Java Edition ([Pomme](https://github.com/PommeMC/Client), GPL-3.0)
в виде Android-приложения `app.erebus.rust`. Исходники Pomme не хранятся здесь: сборка скачивает их с закреплённого
коммита (см. `POMME_SHA` в `settings.gradle.kts`), собирает нативный клиент и APK.

Нужна лицензионная игра и вход через Microsoft. Одиночная игра на Android в Pomme пока отключена,
играть можно на серверах. Первый запуск докачивает ресурсы игры (около 500 МБ). Требуется Vulkan 1.1 (Android 10+).

## Сенсорное управление

Правка `patches/touch-controls.patch` заменяет стандартное управление Pomme на раскладку в стиле Java-лаунчера:
джойстик слева, крупные Hit и Place сверху, Jump и Sneak справа, кнопка Sprint, ряд кнопок F1, F3, F5, Tab, Chat, `/`,
Drop, Pick, Inv и пауза. Остальной экран это обзор. Патч применяется при сборке.
