# Erebus Rust

Отдельный проект: Rust-клиент Minecraft Java Edition ([Pomme](https://github.com/PommeMC/Client), GPL-3.0)
в виде Android-приложения `app.erebus.rust`. Исходники Pomme не хранятся здесь: сборка скачивает их с закреплённого
коммита (см. `POMME_SHA` в `settings.gradle.kts`), собирает нативный клиент и APK.

Нужна лицензионная игра и вход через Microsoft. Одиночная игра на Android в Pomme пока отключена,
играть можно на серверах. Первый запуск докачивает ресурсы игры (около 500 МБ). Требуется Vulkan 1.1 (Android 10+).
